@extends('admin.partials.master')
@section('admin_content')
    <style>
        .card-body {
            background: #425c49;
        }

        .text-muted {
            color: #fff !important;
        }

        h3 {
            color: #fff;
        }
    </style>
    <section id="dashboard-ecommerce">
        <div class="row">
            <div class="col-xl-12 col-12 dashboard-users">
                <label for="">Per Minute is required.</label>
                <input type="text" value="curl -s {{url('commission-interest')}}" class="form-control is-valid">
            </div>
        </div>
    </section>
@endsection
