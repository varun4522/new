<!DOCTYPE html>
<html lang="en">

<head>
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no" />


  <meta property="og:title" content="You earn profit by funding in the cold drink project - ColdDrinkFund" />
  <meta property="og:url" content="https://colddrinkfund.com/" />
  <meta property="og:description" content="You earn profit by funding in the cold drink project - ColdDrinkFund" />
  <meta property="og:site_name" content="You earn profit by funding in the cold drink project - ColdDrinkFund">
  <meta property="og:image" content="https://colddrinkfund.com/img/icon.png" />
  <link href="https://fonts.googleapis.com/css?family=Proxima+Nova:400" rel="stylesheet" />

  <link rel="preconnect" href="https://fonts.googleapis.com" />
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin />
  <link href="https://fonts.googleapis.com/css2?family=Rubik:ital,wght@0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet" />
  <link href="https://fonts.googleapis.com/css2?family=Barlow:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap" rel="stylesheet" />
  <meta content='Privacy Policy, You earn profit by funding in the cold drink project - ColdDrinkFund, You earn profit by funding in the cold drink project - ColdDrinkFund' name='keywords' />
  <meta property="article:tag" content="Privacy Policy, You earn profit by funding in the cold drink project - ColdDrinkFund" name='description' />
  <meta content="Privacy Policy, You earn profit by funding in the cold drink project - ColdDrinkFund" name='DC.title' />
  <meta name="theme-color" content="#69b452">
  <meta name="msapplication-navbutton-color" content="#69b452">
  <meta name="apple-mobile-web-app-status-bar-style" content="#69b452">

  <link rel="icon" type="image/x-icon" href="/img/icon.png" />
  <link rel="shortcut icon" href="/img/icon.png" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-icons/1.9.1/font/bootstrap-icons.min.css" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/line-awesome/1.3.0/line-awesome/css/line-awesome.min.css" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="/css/icofont.min.css" />
  <link href="https://cdn.jsdelivr.net/npm/remixicon@4.3.0/fonts/remixicon.css" rel="stylesheet" />
  <link type="text/css" rel="stylesheet" href="/css/main.css" />
  <link type="text/css" rel="stylesheet" href="/css/head.css" />
  <link type="text/css" rel="stylesheet" href="/css/form.css" />
  <link type="text/css" rel="stylesheet" href="/css/txt.css" />

  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
  <script type="text/javascript" src="./js/out.js"></script>
  <link type="text/css" rel="stylesheet" href="./css/resize.css" />
  <title>Privacy Policy, You earn profit by funding in the cold drink project - ColdDrinkFund</title>
</head>

<body>

  <div class="loading2"></div>
  <div class="all_msg1"></div>
  <div class="all_msg2"></div>
  <div class="sv_back_to_top" id="BackToTop"><i class="fa fa-chevron-up"></i> BACK TO TOP</div>
  <div class="sv_tidio"></div>

  <!-- Google tag (gtag.js) -->
  <script async src="https://www.googletagmanager.com/gtag/js?id=G-3VN0DCMS5M"></script>
  <script>
    window.dataLayer = window.dataLayer || [];

    function gtag() {
      dataLayer.push(arguments);
    }
    gtag('js', new Date());

    gtag('config', 'G-3VN0DCMS5M');
  </script>

  <script>
    //Window Onload In Multipal Use
    var InmSddFunctionOnWindowLoad = function (callback) {
      if (window.addEventListener) {
        window.addEventListener('load', callback, false);
      } else {
        window.attachEvent('onload', callback);
      }
    }
    //Use this type InmSddFunctionOnWindowLoad(window.load function);
    var closepopup = '';

    function load2() {
      $(".loading2").show();
    }

    function rload() {
      setTimeout(function () {
        window.location.href = window.location.href;
      }, 1000);
    }
    $(document).on('click', '.loading2', function () {
      load2();
    });
    $(document).on('click', '.load2', function () {
      load2();
    });
    $(document).on('click', '.load3', function () {
      $('.all_msg2').html('<div class="load3_box"></div>');
    });
    $(document).on('click', '.tload1', function () {
      $('.my_msg1').html('<div class="load3_box"></div>');
    });
  </script>
  <!--Body--S-->
  <div class="my_pbody">
    <div class="my_msg1"></div>
    <div class="my_msg2"></div>
    <div class="my_msg3"></div>
    <!--Menu--S-->
    <div class="my_menu_body">
      <div class="my_menu_tab">
        <div class="my_menu_b1">
          <div class="my_menu_profile">
            <dd><img src="./pimg/7.png" /></dd>
            <dl>
              <nav>
                <span>#<b id="AidCodeCopyHead">CD601E19EAB10</b></span><i class="fa fa-clone" onClick="copyDivToClipboard('AidCodeCopyHead');"></i>
              </nav>
              <h1>Gem </h1>
              <!-- <h2><i class="ri-smartphone-fill"></i>+91 9059216360</h2> -->
            </dl>
          </div>

          <div class="my_menu_exit"><span class="ShowMobileMenuExit"><i class="fa-solid fa-xmark"></i></span></div>
        </div>
        <div class="my_menu_b2">
          <a href="./" class=" load3 minmr2"><span style="color:;"><i class="fa fa-home"></i></span>
            <h2>Home</h2>
            <dl><em class="fa-solid fa-angle-right"></em></dl>
          </a><a href="./user-details.php" class=" load3 minmr2"><span style="color:;"><i class="bi bi-person-circle"></i></span>
            <h2>Profile Details</h2>
            <dl><em class="fa-solid fa-angle-right"></em></dl>
          </a><a href="./cd-plans.php" class=" load3 minmr2"><span style="color:;"><i class="fa-solid fa-chart-simple"></i></span>
            <h2>Our Plans</h2>
            <dl><em class="fa-solid fa-angle-right"></em></dl>
          </a><a href="./my-orders.php" class=" load3 minmr2"><span style="color:;"><i class="bi bi-receipt"></i></span>
            <h2>My Orders</h2>
            <dl><em class="fa-solid fa-angle-right"></em></dl>
          </a><a href="./my-recharge.php" class=" load3 minmr2"><span style="color:;"><i class="fa-solid fa-wallet"></i></span>
            <h2>My Recharge</h2>
            <dl><em class="fa-solid fa-angle-right"></em></dl>
          </a><a href="./my-withdrawal.php" class=" load3 minmr2"><span style="color:;"><i class="fa-solid fa-credit-card"></i></span>
            <h2>My Withdrawal</h2>
            <dl><em class="fa-solid fa-angle-right"></em></dl>
          </a><a href="./my-friends.php" class=" load3 minmr2"><span style="color:;"><i class="ri-team-fill"></i></span>
            <h2>My Friends</h2>
            <dl><em class="fa-solid fa-angle-right"></em></dl>
          </a><a href="./bank-account-update.php?rurl=aHR0cHM6Ly9jb2xkZHJpbmtmdW5kLmNvbS9wcml2YWN5LXBvbGljeS5waHA=" class=" load3 minmr2"><span style="color:;"><i class="ri-bank-card-fill"></i></span>
            <h2>Update Bank</h2>
            <dl><em class="fa-solid fa-angle-right"></em></dl>
          </a><a href="./recharge-records.php" class=" load3 minmr2"><span style="color:;"><i class="bi bi-credit-card-fill"></i></span>
            <h2>Recharge Records</h2>
            <dl><em class="fa-solid fa-angle-right"></em></dl>
          </a><a href="./withdrawal-records.php" class=" load3 minmr2"><span style="color:;"><i class="bi bi-credit-card"></i></span>
            <h2>Withdrawal Records</h2>
            <dl><em class="fa-solid fa-angle-right"></em></dl>
          </a><a href="./change-password.php" class=" load3 minmr2"><span style="color:;"><i class="bi bi-shield-lock-fill"></i></span>
            <h2>Change Password</h2>
            <dl><em class="fa-solid fa-angle-right"></em></dl>
          </a><a href="./raise-a-ticket.php" class=" load3 minmr2"><span style="color:;"><i class="bi bi-ticket-perforated-fill"></i></span>
            <h2>Support Ticket?</h2>
            <dl><em class="fa-solid fa-angle-right"></em></dl>
          </a><a href="./support.php" class=" load3 minmr2"><span style="color:;"><i class="bi bi-chat-text-fill"></i></span>
            <h2>Customer Care?</h2>
            <dl><em class="fa-solid fa-angle-right"></em></dl>
          </a><a href="./frequently-a-questions.php" class=" load3 minmr2"><span style="color:;"><i class="bi bi-question-circle-fill"></i></span>
            <h2>F & Q?</h2>
            <dl><em class="fa-solid fa-angle-right"></em></dl>
          </a><a href="./about-us.php" class=" load3 minmr2"><span style="color:;"><i class="bi bi-info-circle-fill"></i></span>
            <h2>About Us.</h2>
            <dl><em class="fa-solid fa-angle-right"></em></dl>
          </a><a href="./term-and-conditions.php" class=" my_menu_active  load3 minmr2"><span style="color:;"><i class="ri-file-list-3-fill"></i></span>
            <h2>Term & Conditions.</h2>
            <dl><em class="fa-solid fa-angle-right"></em></dl>
          </a><a href="./privacy-policy.php" class=" load3 minmr2"><span style="color:;"><i class="ri-shield-check-fill"></i></span>
            <h2>Privacy Policy.</h2>
            <dl><em class="fa-solid fa-angle-right"></em></dl>
          </a><a href="./logout.php" class=" load3 minmr2"><span style="color:;"><i class="ri-logout-circle-line" style="color:#fff;"></i></span>
            <h2>LogOut.</h2>
            <dl><em class="fa-solid fa-angle-right"></em></dl>
          </a>
        </div>
        <!-- <div class="my_menu_b3">
            <section>
                <dd>
                    <a href="./logout/" class="minmr2 LogOut"><span><i class="ri-logout-circle-line"></i></span>Logout.</a>
                </dd>
                <dl>
                    <a href="./customer-care.php" class="minmr2"><span><i class="fa fa-question-circle"></i></span></a>
                    <a href="./customer-care.php" class="minmr2" style="border-left:1px solid var(--wl2);"><span><i class="fa fa-envelope"></i></span></a>
                </dl>
            </section>
            <article>Made with <i class="fa-solid fa-heart"></i> in india.</article>
        </div> -->

      </div>
    </div>
    <script>
      $(function () {
        $(".ShowMobileMenu").click(function () {

          $(".my_menu_body").fadeIn();
          $(".my_menu_tab").animate({
            left: "0px"
          });
          $(".MenuIconBar").hide();
          $(".MenuIconClose").fadeIn();

        });

        $(".ShowMobileMenuExit").click(function () {
          $(".my_menu_tab").animate({
            left: "-76%"
          });
          $(".my_menu_body").fadeOut();
          $(".MenuIconClose").hide();
          $(".MenuIconBar").fadeIn();
        });

        $('.my_menu_body').click(function (event) {
          if (!$('.my_menu_tab').is(event.target) && $('.my_menu_tab').has(event.target).length === 0) {
            $(".my_menu_tab").animate({
              left: "-76%"
            });
            $(".my_menu_body").fadeOut();
            $(".MenuIconClose").hide();
            $(".MenuIconBar").fadeIn();
          }
        });
      });
      $(document).on('click', '.LogOut', function () {
        var action = 'userLogOut';
        var rurl = '';
        $('.all_msg1').html('<div class="load"><i></i></div>');
        $.post('./__allaction.php', {
          action: action,
          rurl: rurl
        }, function (data) {
          $(".all_msg1").html(data);
        });
      });
    </script>
    <!--Menu--E-->
    <header class="my_thead">
      <section class="my_thead_menu"><a class="minmr2 tload1" href="/mine"><i class="bi bi-caret-left"></i></a></section>
      <section class="my_thead_b1"></section>
      <section class="my_thead_b2">
        <h3>Privacy Policy.</h3>
      </section>
    </header>
    <!--FixBottomMenu--E-->
    <!--FixBottomMenu--E-->
    <style>
      .my_t {
        padding: 5px 15px;
      }
    </style>
    <div class="my_pbody_in" style="bottom: 0;">
      <br />
      <div class="my_note">
        <div class="my_note_in">
          <b>ColdDrinkFund </b> built the Square app as an Ad Supported app. This SERVICE is provided by ColdDrinkFund at no cost and is intended for use as is.
          <br />
          This page is used to inform visitors regarding our policies with the collection, use, and disclosure of Personal Information if anyone decided to use our Service.
          <br />
          If you choose to use our Service, then you agree to the collection and use of information in relation to this policy. The Personal Information that we collect is used for providing and improving the Service. We will not use or share your information with anyone except as described in this Privacy Policy.
          <br />
          The terms used in this Privacy Policy have the same meanings as in our Terms and Conditions, which is accessible at Square unless otherwise defined in this Privacy Policy.
        </div>
      </div>
      <div class="my_t" style="margin-bottom: 0px;">
        <div class="my_t_txt"><i class="fa-solid fa-ellipsis-vertical"></i>Information Collection and Use</div>
      </div>
      <div class="my_note">
        <div class="my_note_in">
          For a better experience, while using our Service, we may require you to provide us with certain personally identifiable information. The information that we request will be retained by us and used as described in this privacy policy.
          <br />
          The app does use third party services that may collect information used to identify you.
          <br />
          Link to privacy policy of third party service providers used by the app
          <br>
          <br>

          <li><a href="https://www.google.com/url?q=https://www.google.com/policies/privacy/&sa=D&ust=1611395223024000&usg=AOvVaw3BsgVULb7qoJY-sER50vEM">Google Play Services</a></li>
          <li><a href="https://www.google.com/url?q=https://www.facebook.com/about/privacy&sa=D&ust=1611395223025000&usg=AOvVaw2lW1UW1YRL4IWRv2T8TKrn">Facebook</a></li>
          <li><a href="https://www.google.com/url?q=https://unity3d.com/legal/privacy-policy&sa=D&ust=1611395223026000&usg=AOvVaw3M9CgUaEQ08r-OpT-RsWVN">Unity Ad</a></li>
        </div>
      </div>

      <div class="my_t" style="margin-bottom: 0px;">
        <div class="my_t_txt"><i class="fa-solid fa-ellipsis-vertical"></i>Log Data</div>
      </div>
      <div class="my_note">
        <div class="my_note_in">

          We want to inform you that whenever you use our Service, in a case of an error in the app we collect data and information (through third party products) on your phone called Log Data. This Log Data may include information such as your device Internet Protocol (“IP”) address, device name, operating system version, the configuration of the app when utilizing our Service, the time and date of your use of the Service, and other statistics.
        </div>
      </div>
      <div class="my_t" style="margin-bottom: 0px;">
        <div class="my_t_txt"><i class="fa-solid fa-ellipsis-vertical"></i>Cookies</div>
      </div>
      <div class="my_note">
        <div class="my_note_in">
          Cookies are files with a small amount of data that are commonly used as anonymous unique identifiers. These are sent to your browser from the websites that you visit and are stored on your device's internal memory.
          <br>
          <br>

          This Service does not use these “cookies” explicitly. However, the app may use third party code and libraries that use “cookies” to collect information and improve their services. You have the option to either accept or refuse these cookies and know when a cookie is being sent to your device. If you choose to refuse our cookies, you may not be able to use some portions of this Service.
        </div>
      </div>
      <div class="my_t" style="margin-bottom: 0px;">
        <div class="my_t_txt"><i class="fa-solid fa-ellipsis-vertical"></i>Service Providers</div>
      </div>
      <div class="my_note">
        <div class="my_note_in">

          We may employ third-party companies and individuals due to the following reasons:
          <br>

          <li>To facilitate our Service;</li>
          <li>To provide the Service on our behalf;</li>
          <li>To perform Service-related services; or</li>
          <li>To assist us in analyzing how our Service is used.</li>
          <br>
          <br>

          We want to inform users of this Service that these third parties have access to your Personal Information. The reason is to perform the tasks assigned to them on our behalf. However, they are obligated not to disclose or use the information for any other purpose.
        </div>
      </div>
      <div class="my_t" style="margin-bottom: 0px;">
        <div class="my_t_txt"><i class="fa-solid fa-ellipsis-vertical"></i>Security</div>
      </div>
      <div class="my_note">
        <div class="my_note_in">
          We value your trust in providing us your Personal Information, thus we are striving to use commercially acceptable means of protecting it. But remember that no method of transmission over the internet, or method of electronic storage is 100% secure and reliable, and we cannot guarantee its absolute security.
        </div>
      </div>
      <div class="my_t" style="margin-bottom: 0px;">
        <div class="my_t_txt"><i class="fa-solid fa-ellipsis-vertical"></i>Links to Other Sites</div>
      </div>
      <div class="my_note">
        <div class="my_note_in">

          This Service may contain links to other sites. If you click on a third-party link, you will be directed to that site. Note that these external sites are not operated by us. Therefore, we strongly advise you to review the Privacy Policy of these websites. We have no control over and assume no responsibility for the content, privacy policies, or practices of any third-party sites or services.
        </div>
      </div>
      <div class="my_t" style="margin-bottom: 0px;">
        <div class="my_t_txt"><i class="fa-solid fa-ellipsis-vertical"></i>Children&rdquo;s Privacy</div>
      </div>
      <div class="my_note">
        <div class="my_note_in">

          These Services do not address anyone under the age of 13. We do not knowingly collect personally identifiable information from children under 13. In the case we discover that a child under 13 has provided us with personal information, we immediately delete this from our servers. If you are a parent or guardian and you are aware that your child has provided us with personal information, please contact us so that we will be able to do necessary actions.
        </div>
      </div>
      <div class="my_t" style="margin-bottom: 0px;">
        <div class="my_t_txt"><i class="fa-solid fa-ellipsis-vertical"></i>Changes to This Privacy Policy</div>
      </div>
      <div class="my_note">
        <div class="my_note_in">

          We may update our Privacy Policy from time to time. Thus, you are advised to review this page periodically for any changes. We will notify you of any changes by posting the new Privacy Policy on this page. These changes are effective immediately after they are posted on this page.
        </div>
      </div>
      <div class="my_t" style="margin-bottom: 0px;">
        <div class="my_t_txt"><i class="fa-solid fa-ellipsis-vertical"></i>Contact Us</div>
      </div>
      <div class="my_note">
        <div class="my_note_in">
          If you have any questions or suggestions about our Privacy Policy, do not hesitate to contact us.
        </div>
      </div>
    </div>


  </div>
  <!--Body--E-->
  <!--Java--S-->
  <script>
  </script>
  <!--Java--E-->
  <script type="text/javascript" src="/js/ac.js"></script>
  <div class="clearfix"></div>
  <script>
    /* $(document).on('click', '.minm_popup_close', function(){
						$('.minm_popup').fadeOut(300);
						var taburl = 'https://colddrinkfund.com/privacy-policy.php';
						//window.history.pushState({},'',taburl);
						window.history.replaceState({}, '', taburl);	
					}); */
    //Empty Link
    $(document).on('click', 'body a', function () {
      //$('body a').click(function(){
      var linkalldata = $(this).attr('href');
      if (typeof linkalldata !== typeof undefined && linkalldata !== false) {
        if (linkalldata.length == 0) {
          $('.all_msg2').html('<div class="give_error_no"><i class="fa fa-exclamation-circle"></i> Page is coming soon please visit some time leta.</div>');
          return false;
        } else {
          return true;
        }
      }
    });
  </script>
  <script src="./js/foot.js"></script>
  <div class="all_fmsg"></div>
  <style>
    @media screen and (max-width:931px) {}

    @media screen and (max-width:768px) {
      body {
        /*	max-width: 420px!important;*/
        margin: 0 auto !important;
      }

      .g11_head1_logo a img {
        max-width: 240px;
      }

      /* .give_error_no, .give_error_yes{
    	display: ;
	} */
    }

    @media screen and (max-width:480px) {}

    @media screen and (max-width:320px) {}
  </style>


  <style>
    /* anim="minmr"*/
    [anim="minmr"] {
      position: relative;
      overflow: hidden;
    }

    .minmr {
      position: relative;
    }

    /* .minmr2{
} */
    [anim="minmr"]:before,
    .minmr:before,
    .minmr2:before {
      content: '';
      position: absolute;
      /*display: block;*/
      background: var(--minmr-background, #999);
      border-radius: 50%;
      pointer-events: none;
      top: calc(var(--y1) * 1px);
      left: calc(var(--x1) * 1px);
      width: calc(var(--d1) * 1px);
      height: calc(var(--d1) * 1px);
      opacity: calc(var(--o1, 1) * var(--minmr-opacity, 0.3));
      transition: calc(var(--t1, 0) * var(--minmr-duration, 600ms)) var(--minmr-easing, linear);
      -webkit-transform: translate(-50%, -50%) scale(var(--s1, 1));
      transform: translate(-50%, -50%) scale(var(--s1, 1));
      -webkit-transform-origin: center;
      transform-origin: center;
    }
  </style>

  <script>
    [].map.call(document.querySelectorAll('[anim="minmr"], .minmr, .minmr2'), function (el) {
      el.addEventListener('click', function (e) {
        e = e.touches ? e.touches[0] : e;
        var r = el.getBoundingClientRect(),
          d = Math.sqrt(Math.pow(r.width, 2) + Math.pow(r.height, 2)) * 2;
        el.style.cssText = "--s1: 0; --o1: 1;";
        el.offsetTop;
        el.style.cssText = "--t1: 1; --o1: 0; --d1: " + d + "; --x1:" + (e.clientX - r.left) + "; --y1:" + (e.clientY - r.top) + ";";
      });
    });
    $(document).on('click', '.load1', function () {
      $('.load').fadeIn(100);
    });
  </script>

  <!--Audio--S-->
  <script>
    function ClickBtnPlay() {
      var audio = document.getElementById("ClickBtnPlay");
      audio.play();
    }

    $(document).on('click', '.BtnPlay', function () {
      ClickBtnPlay();
    });

    function completeOrderPlay() {
      var audio2 = document.getElementById("completeOrderPlay");
      audio2.play();
    }

    function processMusicPlay() {
      var audio3 = document.getElementById("processMusicPlay");
      audio3.play();
    }
  </script>
  <audio id="ClickBtnPlay" src=""></audio>
  <audio id="completeOrderPlay" src=""></audio>
  <audio id="processMusicPlay" src=""></audio>

  <!--Audio--E-->
  <script>
    $(document).ready(function (e) {
      //AccountRefresh
      $(document).on('click', '.AccountRefresh', function () {
        $('.my_msg1').html('<div class="load"></div>');
        var action = 'AccountRefresh';
        $.post('./__ac_action.php', {
          action: action
        }, function (data) {
          $(".my_msg1").html(data);
        });
      });
      //WalletRefresh
      $(document).on('click', '.WalletRefresh', function () {
        $('.my_msg1').html('<div class="load"></div>');
        var action = 'WalletRefresh';
        $.post('./__ac_action.php', {
          action: action
        }, function (data) {
          $(".my_msg1").html(data);
        });
      });
      $(document).on('click', '.MsgPopupClose', function () {
        $('.MsgPopup').fadeOut(300);
      });
      $('body, html').click(function (event) {
        if ((!$('.sv_popup_in').is(event.target) && $('.sv_popup_in').has(event.target).length === 0)) {
          $('.MsgPopup').fadeOut(300);
        }
      });

      if (screen.width <= 768) {

      } else {}

      $(document).on("click", "#BackToTop", function () {
        $("body,html").animate({
          scrollTop: 0
        }, 500);
      });
      $(window).scroll(function () {
        if ($(this).scrollTop() >= 50) {
          $("#BackToTop").fadeIn(200);
        } else {
          $("#BackToTop").fadeOut(200);
        }
      });

      //Empty Link
      $(document).on('click', 'body a', function () {
        //$("body a").click(function(){
        var linkalldata = $(this).attr("href");
        if (typeof linkalldata !== typeof undefined && linkalldata !== false) {
          if (linkalldata.length == 0) {
            $(".all_msg2").html('<div class="give_error_no"><dd><i class="fa fa-exclamation-circle"></i></dd>Page is coming soon please visit some time leta.</div>');
            setTimeout(function () {
              rload()
            }, 2000);
            return false;
          } else {
            return true;
          }
        }
      });
      window.addEventListener("load", function (event) {
        lazyload();
      });

    });
  </script>
  <script defer src="https://static.cloudflareinsights.com/beacon.min.js/vcd15cbe7772f49c399c6a5babf22c1241717689176015" integrity="sha512-ZpsOmlRQV6y907TI0dKBHq9Md29nnaEIPlkf84rnaERnq6zvWvPUqr2ft8M1aS28oN72PdrCzSjY4U6VaAw1EQ==" data-cf-beacon='{"version":"2024.11.0","token":"3488a88409724353a65cd0f4b9d0d950","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
</body>

</html>